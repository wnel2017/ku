<td align=center><img src="https://raw.githubusercontent.com/wnel2017/3tui/master/3T(3).jpg"/></td> 

◆<a href="https://s3.ap-south-1.amazonaws.com/ogatem/oGate.htm?ogST.aspx?from=wnel">请点击在线快速办理</a>，全球近3亿人的幸运选择，珍贵机缘，为你而来，这一次您千万别错过～

◆<a href="https://s3.ap-south-1.amazonaws.com/ogatem/oGate.htm?4EC%2FST&from=st?from=wnel">〝三退〞到底是件什么事？</a>

◆中共不等于中国，中共一直在用谎言与暴力迫害中国民众，导致八千多万中国同胞非正常死亡，现在仍然在迫害善良的中国人。截至昨日，已有 269,386,319 人声明“三退”（退出中共邪党及其附属的共青团、少先队组织），每天可达十多万人。

◆有人说“自己心中退党（团队）就算退了，不必声明”，还有人认为“自己多年没交党费了，就算自动退党了”，“超龄了，就自动退团（队）了”。 但这都不能抹掉举着右手宣誓时被打上的印记。只有声明退出中共党、团、队组织，才能解除毒誓，在天灭中共时免于被淘汰，为自己选择美好的未来。

◆您在这里“三退”（几分钟就可以）是安全的，用真名、化名都可以。不仅不会影响您的工作与生活，反而会遇难呈祥，逢凶化吉。


* 请三小时后务必查询是否办理成功，并且人数正确。如果不正确，可以在“我叫”中写上编号，在“我要说”中反馈情况。
* 代办需要本人明确同意，并且本人知道是怎么写的。
* 化名请使用正常的中文名字；不要只用姓、字母、数字。
* 化名尽量避免使用太常用的化名，如平安，吉祥，如意，顺利，幸福，成功，快乐，发财等；避免使用邪党头子或者邪党树立的所谓英雄人物作化名。
* 化名避免使用王一、王二、王三、王四、王五等这样姓加编号的方式。
* 参考资料：

◆<a href="https://s3.ap-south-1.amazonaws.com/ogatem/oGate.htm?4EC%2FMTDWH.mp4&from=wnel">漫谈党文化</a>
◆<a href="https://s3.ap-south-1.amazonaws.com/ogatem/oGate.htm?1D%2FJTDWH&from=wnel">解体党文化</a><br/>
◆<a href="https://s3.ap-south-1.amazonaws.com/ogatem/oGate.htm?4EC%2FBNGCD&from=wnel">百年共产党</a>
◆<a href="https://s3.ap-south-1.amazonaws.com/ogatem/oGate.htm?c816602&from=wnel">马克思的成魔之路</a>
<table>
  <tr>
<td align=center><img src="https://raw.githubusercontent.com/wnel2017/3tui/master/3T.jpg"/></td>
  </tr>
  <tr>
  <td align=center>◆九评共产党 , 热传全球13年 <br/>
  让你看懂中国，让你看清世界<br/>
<a href="https://s3.ap-south-1.amazonaws.com/ogatem/oGate.htm?4EC%2FJP.mp4&from=wnel">请点击 九评共产党</a><br/>
  </tr>
  <tr>
    <td align=center><img src="https://raw.githubusercontent.com/wnel2017/wm/master/ogate2.jpg" /></td>
  </tr>
  <tr>
    <td align=center>网门 網門<br/>
      欢迎来到固定网址页面，请收藏<br/>
      本页面 https://git.io/ogate<br/>
      推荐谷歌或火狐浏览器<br/>
      国产浏览器会干扰访问<br/>
    </td>
  </tr>
  <tr>
    <td align=center>大陆用户请点击进入<br/>
      <a href="https://s3.ap-south-1.amazonaws.com/ogatem/oGate.htm?from=wnel">◆◆动态网址◆◆</a><br/>
      微信如果提示：停止访问该网页<br/>
      请点击右上角，选择浏览器打开<br/>
    </td>
  </tr>
  <tr>
    <td align=center>手机用户推荐安装最新版<br/>
      安卓版 <a href="https://raw.githubusercontent.com/ogate/up/master/ogate.apk?og">https://git.io/ogatea</a><br/>
    </td>
  </tr>
  <tr>
    <td align=center>电脑用户请下载最新版<br/>
      安卓版 <a href="https://raw.githubusercontent.com/ogate/up/master/ogatew.zip">https://git.io/opipe</a><br/>
    </td>
  </tr>
  <tr>
    <td align=center>
      <a href="https://github.com/ogate/onews/blob/master/README.md?from=wnel">网门新闻</a><br/>
    </td>
  </tr>
  <tr>
    <td align=center><img src="https://cloud.githubusercontent.com/assets/11880933/15631437/70d0a74e-259d-11e6-946f-6237b4b657bd.jpg"/></td>
  </tr>
  <tr>
    <td align=center>
大陆用户无需翻墙，直接登入《网门》<br/>
自由浏览 全球精粹与热门互联网资源<br/>
《网门》揭开网络时代的新视角<br/>
《网门》引领网络时代的新风尚<br/>
《网门》适合手机、平板、电脑<br/>
《网门》适合所有网络终端用户<br/>
《网门》无需翻墙突破网络封锁<br/>
《网门》是稳定长效的安全网址<br/>
请把网址保存在手机浏览器书签中<br/>
请把网址保存在电脑浏览器收藏夹<br/>
就可随时上《网门》浏览全球精粹资源<br/></td>
  </tr>
</table>    
